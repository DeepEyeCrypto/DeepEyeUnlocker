package com.deepeye.otg.usb

// =============================================================================
// UsbLifecycleManagerFix.kt
// Bug fix: pass real UsbDevice object AND feature string to BypassViewModel
// =============================================================================

// ADD this function inside your existing UsbLifecycleManager class:
// (Find where you already call something like viewModel.onDeviceConnected()
//  and replace it with this pattern)

/*
FIND THIS in your UsbLifecycleManager (existing code):

    private fun handleDeviceAttach(device: UsbDevice) {
        ...
        viewModel.onDeviceConnected(deviceState)   // ← OLD — missing UsbDevice
        ...
    }

REPLACE WITH:

    private fun handleDeviceAttach(device: UsbDevice) {

        // Step 1: Parse feature string if V6 device
        // Feature string comes from USB Product Name descriptor
        // e.g. "hw_code:0x1209;feature:V6;key:02;sn:LZN7EERSZPS4VSUG"
        val featureStr = device.productName
            ?.takeIf { it.startsWith("hw_code:") }

        Timber.d("[USB_LM] device attach " +
                 "vid=0x${device.vendorId.toString(16)} " +
                 "pid=0x${device.productId.toString(16)} " +
                 "featureStr=$featureStr")

        // Step 2: Pass BOTH UsbDevice and featureStr to ViewModel
        viewModel.onUsbDeviceConnected(
            usbDevice  = device,      // ← THE FIX: real UsbDevice object
            featureStr = featureStr,
        )
    }

    private fun handleDeviceDetach(device: UsbDevice) {
        viewModel.onUsbDeviceDisconnected()
    }
*/

// ── Also fix UsbPermissionHandler.kt ─────────────────────────────────────────
/*
FIND in UsbPermissionHandler (after permission granted):

    override fun onReceive(context: Context, intent: Intent) {
        val device = intent.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
        val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)

        if (granted && device != null) {
            // OLD: just open session without passing device to ViewModel
            sessionManager.openSession(device)
        }
    }

REPLACE WITH:

    override fun onReceive(context: Context, intent: Intent) {
        val device  = intent.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
        val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)

        if (granted && device != null) {
            // Step 1: open session
            sessionManager.openSession(device)

            // Step 2: ★ FIX — notify ViewModel with actual UsbDevice
            val featureStr = device.productName
                ?.takeIf { it.startsWith("hw_code:") }

            Timber.d("[USB_PERM] permission granted → notifying ViewModel " +
                     "vid=0x${device.vendorId.toString(16)} " +
                     "featureStr=$featureStr")

            viewModel.onUsbDeviceConnected(
                usbDevice  = device,
                featureStr = featureStr,
            )
        }
    }
*/

// ── Also fix UsbSessionManager.kt ─────────────────────────────────────────────
/*
ADD this public property to UsbSessionManager:

    // Expose current connected device
    var currentUsbDevice: UsbDevice? = null
        private set

    fun openSession(device: UsbDevice) {
        currentUsbDevice = device   // ← store it
        // ... rest of existing code
    }

    fun closeSession() {
        currentUsbDevice = null
        // ... rest of existing code
    }
*/
