package com.deepeye.otg.ui.gsmg

// =============================================================================
// BUG FIX SUMMARY
// =============================================================================
//
// BUG 1: [USB_REQUIRED] on MTK Hydra FRP
//   Root cause: usbDevice not passed from ViewModel to Engine
//   Fix: UsbSessionManager.connectedDevice() → pass to execute()
//
// BUG 2: [NOT_IMPLEMENTED] QC EDL shown on MTK device (Realme 14x)
//   Root cause: Features not filtered by detected protocol family
//   Fix: Filter displayed features based on device's actual protocol
//
// =============================================================================

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import android.hardware.usb.UsbDevice
import com.deepeye.otg.data.gsmg.*
import com.deepeye.otg.data.ProtocolFamily
import com.deepeye.otg.data.UniversalProtocolDetector
import com.deepeye.otg.usb.UsbSessionManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import java.util.UUID
import javax.inject.Inject

// ── Bug Fix 1: ViewModel must hold UsbDevice reference ───────────────────────

@HiltViewModel
class BypassViewModel @Inject constructor(
    private val bypassEngine:   UniversalBypassEngine,
    private val usbSessionMgr:  UsbSessionManager,     // ← ADD THIS INJECTION
) : ViewModel() {

    private val _state = MutableStateFlow(BypassUiState())
    val state: StateFlow<BypassUiState> = _state.asStateFlow()

    // ★ FIX: Store actual UsbDevice reference — not just DeviceState
    private var _connectedUsbDevice: UsbDevice? = null
    private var _detectedProtocol:   ProtocolFamily? = null
    private var _deviceFeatureStr:   String? = null  // V6 hello string
    private var executeJob: Job? = null

    // ── Called from UsbLifecycleManager when device attaches ─────────────────

    fun onUsbDeviceConnected(
        usbDevice:  UsbDevice,
        featureStr: String?,   // V6 hello: "hw_code:0x1209;feature:V6;key:02"
    ) {
        _connectedUsbDevice = usbDevice
        _deviceFeatureStr   = featureStr

        // Detect protocol from VID+PID+featureStr
        val iface = runCatching { usbDevice.getInterface(0) }.getOrNull()
        val detection = UniversalProtocolDetector.detect(
            vid           = usbDevice.vendorId,
            pid           = usbDevice.productId,
            featureStr    = featureStr,
            ifaceClass    = iface?.interfaceClass    ?: -1,
            ifaceSubclass = iface?.interfaceSubclass ?: -1,
            ifaceProto    = iface?.interfaceProtocol ?: -1,
        )
        _detectedProtocol = detection.protocol

        Timber.d("[BYPASS_VM] usb_connected " +
                 "vid=0x${usbDevice.vendorId.toString(16)} " +
                 "pid=0x${usbDevice.productId.toString(16)} " +
                 "protocol=${detection.protocol} " +
                 "hwCode=0x${detection.hwCode.toString(16)}")

        // Build DeviceState from detection
        val deviceState = buildDeviceState(usbDevice, detection, featureStr)

        // ★ FIX BUG 2: Filter features by ACTUAL protocol of connected device
        val allFeatures    = UnifiedBypassRegistry.all
        val filteredFeatures = filterFeaturesForDevice(allFeatures, detection)

        _state.update { s ->
            s.copy(
                device            = deviceState,
                allFeatures       = filteredFeatures,
                displayedFeatures = applyFilters(filteredFeatures, s.filters),
                totalAvailable    = filteredFeatures.size,
                freeCount         = filteredFeatures.count { it.isFree },
                recommendation    = UnifiedBypassRegistry.recommend(deviceState),
            )
        }
    }

    fun onUsbDeviceDisconnected() {
        _connectedUsbDevice = null
        _detectedProtocol   = null
        _deviceFeatureStr   = null
        cancelExecution()

        val all = UnifiedBypassRegistry.all
        _state.update { s ->
            s.copy(
                device            = null,
                allFeatures       = all,
                displayedFeatures = applyFilters(all, s.filters),
                recommendation    = null,
                isExecuting       = false,
            )
        }
    }

    // ── Execute fix ───────────────────────────────────────────────────────────

    fun onRequestExecute(feature: BypassFeature) {
        val device    = _state.value.device ?: return
        val sessionId = UUID.randomUUID().toString()
        val plan      = UnifiedBypassRegistry.buildPlan(feature, device, sessionId)

        if (feature.dataLoss || feature.riskLevel >= RiskLevel.HIGH) {
            _state.update { it.copy(activePlan = plan, showPlanDialog = true) }
        } else {
            startExecution(feature, device, sessionId)
        }
    }

    fun onConfirmPlan() {
        val plan = _state.value.activePlan ?: return
        _state.update { it.copy(showPlanDialog = false) }
        startExecution(plan.feature, plan.device, plan.sessionId)
    }

    private fun startExecution(
        feature:   BypassFeature,
        device:    DeviceState,
        sessionId: String,
    ) {
        if (_state.value.isExecuting) return

        // ★ FIX BUG 1: Pass actual UsbDevice to engine
        val usbDevice = _connectedUsbDevice
        if (usbDevice == null && feature.requiresDfu) {
            _state.update { it.copy(
                errorMessage = "USB device not connected. Connect via OTG cable."
            )}
            return
        }

        Timber.d("[BYPASS_VM] execute feature=${feature.id} " +
                 "usbDevice=${usbDevice?.deviceName} " +
                 "sessionId=$sessionId")

        _state.update { it.copy(
            activeFeatureId = feature.id,
            isExecuting     = true,
            activeEvents    = emptyList(),
            latestEvent     = null,
            errorMessage    = null,
            successMessage  = null,
        )}

        executeJob = viewModelScope.launch {
            bypassEngine.execute(
                feature     = feature,
                device      = device,
                usbDevice   = usbDevice,         // ← THE FIX
                featureStr  = _deviceFeatureStr,
                sessionId   = sessionId,
            ).collect { event ->
                _state.update { it.copy(
                    latestEvent  = event,
                    activeEvents = it.activeEvents + event,
                )}
                when (event) {
                    is BypassEvent.Completed -> _state.update { it.copy(
                        isExecuting    = false,
                        successMessage = buildSuccess(event, feature),
                    )}
                    is BypassEvent.Failed -> _state.update { it.copy(
                        isExecuting  = false,
                        errorMessage = "[${event.layer}] ${event.reason}",
                    )}
                    else -> Unit
                }
            }
        }
    }

    // ── Bug Fix 2: Filter features by actual device protocol ─────────────────

    private fun filterFeaturesForDevice(
        features:  List<BypassFeature>,
        detection: UniversalProtocolDetector.DetectionResult,
    ): List<BypassFeature> {
        val proto = detection.protocol

        return features.filter { feature ->
            when (feature.mechanism) {

                // QC EDL features → only show on QC devices
                BypassMechanism.FRP_QC_EDL,
                BypassMechanism.NV_READ_WRITE,
                BypassMechanism.EFS_BACKUP_RESTORE,
                BypassMechanism.IMEI_REPAIR_QC ->
                    proto == ProtocolFamily.QC_EDL ||
                    proto == ProtocolFamily.QC_DIAG ||
                    proto == ProtocolFamily.ADB_GENERIC  // ADB route also valid

                // MTK BROM/V6 features → only show on MTK devices
                BypassMechanism.FRP_MTK_BROM,
                BypassMechanism.FRP_MTK_META,
                BypassMechanism.SLA_AUTH,
                BypassMechanism.IMEI_REPAIR_MTK ->
                    proto in listOf(
                        ProtocolFamily.MTK_V6,
                        ProtocolFamily.MTK_BROM_CLASSIC,
                        ProtocolFamily.MTK_META,
                        ProtocolFamily.ADB_GENERIC,
                    )

                // Samsung ODIN → only Samsung
                BypassMechanism.FRP_DOWNLOAD_MODE,
                BypassMechanism.FRP_SAMSUNG_MTP,
                BypassMechanism.FRP_SAMSUNG_MODEM,
                BypassMechanism.DRK_REPAIR,
                BypassMechanism.CSC_CHANGE,
                BypassMechanism.IMEI_REPAIR_SAMSUNG ->
                    proto == ProtocolFamily.SAMSUNG_ODIN ||
                    proto == ProtocolFamily.ADB_GENERIC

                // SPD/UniSoc → only UniSoc
                BypassMechanism.FRP_SPD,
                BypassMechanism.SPD_DOWNLOAD_MODE,
                BypassMechanism.UNISOC_META,
                BypassMechanism.IMEI_REPAIR_SPD ->
                    proto == ProtocolFamily.SPD_UNISOC ||
                    proto == ProtocolFamily.ADB_GENERIC

                // iOS features → only Apple devices
                BypassMechanism.CHECKM8,
                BypassMechanism.CHECKM8_IRAIN,
                BypassMechanism.CHECKM8_RAMDISK,
                BypassMechanism.IRAIN,
                BypassMechanism.RAMDISK,
                BypassMechanism.RAMDISK_READ,
                BypassMechanism.RAMDISK_WRITE,
                BypassMechanism.RAMDISK_DELETE,
                BypassMechanism.NVRAM_INJECTION,
                BypassMechanism.DFU_RESTORE,
                BypassMechanism.CUSTOM_IPSW,
                BypassMechanism.USB_SEQUENCE,
                BypassMechanism.ACTIVATION_PATCH,
                BypassMechanism.ACTIVATION_RECORD_PATCH,
                BypassMechanism.INTEGRITY_PATCH ->
                    proto in listOf(
                        ProtocolFamily.IOS_DFU,
                        ProtocolFamily.IOS_RECOVERY,
                        ProtocolFamily.IOS_NORMAL,
                    )

                // ADB / Server / Universal → always show
                BypassMechanism.ADB_EXPLOIT,
                BypassMechanism.FRP_ADB,
                BypassMechanism.SERVER_EXPLOIT,
                BypassMechanism.SERVER_REGISTRATION,
                BypassMechanism.DIRECT_UNLOCK,
                BypassMechanism.CODE_GENERATE,
                BypassMechanism.USB_READ,
                BypassMechanism.BOOTLOADER_UNLOCK,
                BypassMechanism.MI_ACCOUNT_REMOVE,
                BypassMechanism.HUAWEI_ID_REMOVE,
                BypassMechanism.OPPO_ID_REMOVE,
                BypassMechanism.SCREEN_LOCK_REMOVE,
                BypassMechanism.MDM_PAYJOY_REMOVE,
                BypassMechanism.MAC_REPAIR,
                BypassMechanism.CALIBRATION_RESTORE,
                BypassMechanism.VOICE_ENABLE,
                BypassMechanism.MODEM_UNLOCK_HUAWEI,
                BypassMechanism.MODEM_UNLOCK_ZTE,
                BypassMechanism.MODEM_UNLOCK_SIERRA,
                BypassMechanism.AT_COMMAND,
                BypassMechanism.DIAG_UNLOCK,
                BypassMechanism.EMMC_HEALTH_CHECK,
                BypassMechanism.RPMB_BACKUP,
                BypassMechanism.RPMB_RESTORE,
                BypassMechanism.PARTITION_MANAGER,
                BypassMechanism.FIRMWARE_FLASH_MTK,
                BypassMechanism.FIRMWARE_FLASH_QC,
                BypassMechanism.FIRMWARE_FLASH_SPD,
                BypassMechanism.FIRMWARE_FLASH_ODIN,
                BypassMechanism.FIRMWARE_FLASH_HUAWEI,
                BypassMechanism.BOOTLOADER_RELOCK -> true
            }
        }
    }

    // ── DeviceState builder from USB detection ────────────────────────────────

    private fun buildDeviceState(
        usbDevice:  UsbDevice,
        detection:  UniversalProtocolDetector.DetectionResult,
        featureStr: String?,
    ): DeviceState {
        // Parse serial from V6 feature string
        val serial = featureStr
            ?.split(";")
            ?.firstOrNull { it.startsWith("sn:") }
            ?.removePrefix("sn:")

        val chip  = com.deepeye.otg.data.MtkChipDatabase.find(detection.hwCode)
        val isIos = detection.protocol in listOf(
            ProtocolFamily.IOS_DFU, ProtocolFamily.IOS_RECOVERY, ProtocolFamily.IOS_NORMAL
        )

        return DeviceState(
            sessionId    = UUID.randomUUID().toString(),
            ecid         = null,
            imei         = null,
            serial       = serial ?: usbDevice.serialNumber,
            chipName     = chip?.chipName
                           ?: detection.brand
                           ?: "Unknown (0x${usbDevice.vendorId.toString(16)}:0x${usbDevice.productId.toString(16)})",
            chipRange    = when (detection.protocol) {
                ProtocolFamily.IOS_DFU      -> ChipRange.A7_TO_A18
                ProtocolFamily.IOS_RECOVERY -> ChipRange.A7_TO_A18
                ProtocolFamily.IOS_NORMAL   -> ChipRange.A7_TO_A18
                ProtocolFamily.MTK_V6       -> ChipRange.MTK_V6
                ProtocolFamily.MTK_BROM_CLASSIC,
                ProtocolFamily.MTK_META     -> ChipRange.MTK_CLASSIC
                ProtocolFamily.QC_EDL,
                ProtocolFamily.QC_DIAG,
                ProtocolFamily.FASTBOOT     -> ChipRange.QC_ALL
                ProtocolFamily.SAMSUNG_ODIN -> ChipRange.SAMSUNG_ALL
                ProtocolFamily.SPD_UNISOC   -> ChipRange.SPD_ALL
                else                        -> ChipRange.ALL_ANDROID
            },
            iosVersion   = if (isIos) "" else "Android",
            buildNumber  = null,
            isJailbroken = false,
            fmiEnabled   = false,
            imeiPresent  = false,
            imeiValid    = false,
            isCdmaMeid   = false,
            activated    = false,
            mdmEnrolled  = false,
            dfuMode      = detection.protocol == ProtocolFamily.IOS_DFU,
            androidBrand = detection.brand,
            androidModel = null,
            androidChip  = chip?.chipName,
            adbAvailable = detection.protocol == ProtocolFamily.ADB_GENERIC,
            edlAvailable = detection.protocol == ProtocolFamily.QC_EDL,
            metaAvailable= detection.protocol == ProtocolFamily.MTK_META,
        )
    }

    // ── Standard helpers ──────────────────────────────────────────────────────

    fun cancelExecution() {
        executeJob?.cancel()
        executeJob = null
        _state.update { it.copy(isExecuting = false) }
    }

    fun onDismissPlan()    { _state.update { it.copy(showPlanDialog = false, activePlan = null) } }
    fun onClearError()     { _state.update { it.copy(errorMessage = null) } }
    fun onClearSuccess()   { _state.update { it.copy(successMessage = null) } }
    fun onShowDetail(id: String?) { _state.update { it.copy(detailFeatureId = id) } }

    private fun applyFilters(
        features: List<BypassFeature>,
        filters:  BypassFilters,
    ): List<BypassFeature> {
        var list = features
        filters.category?.let  { list = list.filter { f -> f.category == it } }
        filters.source?.let    { list = list.filter { f -> f.source == it } }
        if (filters.freeOnly)    list = list.filter { it.isFree }
        if (filters.signalOnly)  list = list.filter { it.signalAfter }
        if (filters.untethered)  list = list.filter { it.untethered }
        if (filters.noDataLoss)  list = list.filter { !it.dataLoss }
        if (filters.noJailbreak) list = list.filter { !it.requiresJailbreak }
        if (filters.searchQuery.length >= 2) {
            val q = filters.searchQuery.lowercase()
            list = list.filter { f ->
                q in f.displayName.lowercase() ||
                q in f.description.lowercase() ||
                f.tags.any { q in it }
            }
        }
        return list.sortedWith(compareBy({ it.category.ordinal }, { it.costCredits }))
    }

    private fun buildSuccess(ev: BypassEvent.Completed, f: BypassFeature) =
        buildString {
            append("✅ ${f.displayName} complete. ")
            if (ev.signalEnabled) append("📶 Signal active. ")
            if (ev.iServices)     append("💬 iServices active. ")
            if (ev.untethered)    append("🔄 Persists after reboot.")
            else                  append("⚠ Re-run after power cycle.")
        }

    override fun onCleared() {
        super.onCleared()
        executeJob?.cancel()
    }
}
