package com.deepeye.otg.ui.gsmg

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.deepeye.otg.data.gsmg.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import java.util.UUID
import javax.inject.Inject

// =============================================================================
// BypassViewModel.kt v4.0
// Supports iOS + Android + Modem/Router features across 7 tools
// =============================================================================

enum class DevicePlatform { IOS, ANDROID, MODEM_ROUTER, UNKNOWN }

data class BypassFilters(
    val category:       FeatureCategory? = null,
    val source:         FeatureSource?   = null,
    val platform:       DevicePlatform   = DevicePlatform.UNKNOWN,
    val freeOnly:       Boolean          = false,
    val signalOnly:     Boolean          = false,
    val untethered:     Boolean          = false,
    val noDataLoss:     Boolean          = false,
    val noJailbreak:    Boolean          = false,
    val offlineOnly:    Boolean          = false,
    val searchQuery:    String           = "",
    val brandFilter:    String           = "",
)

data class BypassUiState(
    val allFeatures:       List<BypassFeature>       = emptyList(),
    val displayedFeatures: List<BypassFeature>       = emptyList(),
    val filters:           BypassFilters             = BypassFilters(),
    val device:            DeviceState?              = null,
    val recommendation:    RecommendationResult?     = null,

    val wantSignal:        Boolean                   = false,
    val wantFree:          Boolean                   = false,
    val wantUntethered:    Boolean                   = false,

    val activePlan:        ExecutionPlan?            = null,
    val activeFeatureId:   String?                   = null,
    val activeEvents:      List<BypassEvent>         = emptyList(),
    val latestEvent:       BypassEvent?              = null,
    val isExecuting:       Boolean                   = false,
    val showPlanDialog:    Boolean                   = false,
    val detailFeatureId:   String?                   = null,

    val errorMessage:      String?                   = null,
    val successMessage:    String?                   = null,

    // Stats
    val totalAvailable:    Int                       = 0,
    val freeCount:         Int                       = 0,
    val signalCount:       Int                       = 0,
    val sourceBreakdown:   Map<FeatureSource, Int>   = emptyMap(),
    val categoryBreakdown: Map<FeatureCategory, Int> = emptyMap(),

    // Platform tabs
    val selectedPlatform:  DevicePlatform            = DevicePlatform.UNKNOWN,
)

@HiltViewModel
class BypassViewModel @Inject constructor() : ViewModel() {

    private val _state = MutableStateFlow(BypassUiState())
    val state: StateFlow<BypassUiState> = _state.asStateFlow()

    private var executeJob: Job? = null

    init {
        val all = UnifiedBypassRegistry.all
        _state.update { s ->
            s.copy(
                allFeatures       = all,
                displayedFeatures = applyFilters(all, s.filters),
                totalAvailable    = UnifiedBypassRegistry.total,
                freeCount         = UnifiedBypassRegistry.freeCount,
                signalCount       = UnifiedBypassRegistry.signalCount,
                sourceBreakdown   = UnifiedBypassRegistry.countBySource(),
                categoryBreakdown = UnifiedBypassRegistry.countByCategory(),
            )
        }
        Timber.d("[BYPASS_VM] init total=${UnifiedBypassRegistry.total}")
    }

    // ── Device ────────────────────────────────────────────────────────────────

    fun onDeviceConnected(device: DeviceState) {
        Timber.d("[BYPASS_VM] device chip=${device.chipName} android=${device.androidBrand} " +
                 "sessionId=${device.sessionId}")

        val available = UnifiedBypassRegistry.forChip(device.chipRange)
        val rec = UnifiedBypassRegistry.recommend(
            device         = device,
            wantSignal     = _state.value.wantSignal,
            wantFree       = _state.value.wantFree,
            wantUntethered = _state.value.wantUntethered,
        )

        val platform = when {
            device.chipRange in listOf(
                ChipRange.A7_TO_A11, ChipRange.A8_TO_A11,
                ChipRange.A12_TO_A18, ChipRange.A7_TO_A18,
            ) -> DevicePlatform.IOS
            device.chipRange == ChipRange.MODEM_ALL -> DevicePlatform.MODEM_ROUTER
            else -> DevicePlatform.ANDROID
        }

        _state.update { s ->
            s.copy(
                device            = device,
                allFeatures       = available,
                displayedFeatures = applyFilters(available, s.filters.copy(platform = platform)),
                recommendation    = rec,
                selectedPlatform  = platform,
                totalAvailable    = available.size,
                freeCount         = available.count { it.isFree },
                signalCount       = available.count { it.signalAfter },
                sourceBreakdown   = available.groupBy { it.source }.mapValues { it.value.size },
                categoryBreakdown = available.groupBy { it.category }.mapValues { it.value.size },
            )
        }
    }

    fun onDeviceDisconnected() {
        cancelExecution()
        val all = UnifiedBypassRegistry.all
        _state.update { s ->
            s.copy(
                device            = null,
                recommendation    = null,
                allFeatures       = all,
                displayedFeatures = applyFilters(all, s.filters),
                totalAvailable    = UnifiedBypassRegistry.total,
                freeCount         = UnifiedBypassRegistry.freeCount,
                signalCount       = UnifiedBypassRegistry.signalCount,
                isExecuting       = false,
                activeFeatureId   = null,
                activeEvents      = emptyList(),
                latestEvent       = null,
            )
        }
    }

    // ── Platform tab ──────────────────────────────────────────────────────────


    fun onSelectPlatform(platform: DevicePlatform) {
        val base = when (platform) {
            DevicePlatform.IOS          -> UnifiedBypassRegistry.forIos()
            DevicePlatform.ANDROID      -> UnifiedBypassRegistry.forAndroid()
            DevicePlatform.MODEM_ROUTER -> UnifiedBypassRegistry.modemRouter()
            DevicePlatform.UNKNOWN      -> UnifiedBypassRegistry.all
        }
        _state.update { s ->
            val newFilters = s.filters.copy(platform = platform)
            s.copy(
                selectedPlatform  = platform,
                allFeatures       = base,
                filters           = newFilters,
                displayedFeatures = applyFilters(base, newFilters),
                totalAvailable    = base.size,
                freeCount         = base.count { it.isFree },
                signalCount       = base.count { it.signalAfter },
                categoryBreakdown = base.groupBy { it.category }.mapValues { it.value.size },
                sourceBreakdown   = base.groupBy { it.source }.mapValues { it.value.size },
            )
        }
    }

    // ── Filters ───────────────────────────────────────────────────────────────

    fun onCategoryFilter(cat: FeatureCategory?) = updateFilters { copy(category = cat) }
    fun onSourceFilter(src: FeatureSource?)     = updateFilters { copy(source = src) }
    fun onToggleFreeOnly()    = updateFilters { copy(freeOnly    = !freeOnly) }
    fun onToggleSignalOnly()  = updateFilters { copy(signalOnly  = !signalOnly) }
    fun onToggleUntethered()  = updateFilters { copy(untethered  = !untethered) }
    fun onToggleNoDataLoss()  = updateFilters { copy(noDataLoss  = !noDataLoss) }
    fun onToggleNoJailbreak() = updateFilters { copy(noJailbreak = !noJailbreak) }
    fun onToggleOfflineOnly() = updateFilters { copy(offlineOnly = !offlineOnly) }
    fun onSearch(q: String)   = updateFilters { copy(searchQuery = q) }
    fun onBrandFilter(b: String) = updateFilters { copy(brandFilter = b) }
    fun clearFilters() = updateFilters { copy(
        category = null, source = null, freeOnly = false,
        signalOnly = false, untethered = false, noDataLoss = false,
        noJailbreak = false, offlineOnly = false,
        searchQuery = "", brandFilter = "",
    )}

    private fun updateFilters(transform: BypassFilters.() -> BypassFilters) {
        _state.update { s ->
            val f = s.filters.transform()
            s.copy(filters = f, displayedFeatures = applyFilters(s.allFeatures, f))
        }
    }

    // ── Recommendation ────────────────────────────────────────────────────────

    fun onRefineRecommendation(signal: Boolean, free: Boolean, unt: Boolean) {
        val device = _state.value.device ?: return
        val rec = UnifiedBypassRegistry.recommend(device, signal, free, unt)
        _state.update { it.copy(wantSignal = signal, wantFree = free, wantUntethered = unt, recommendation = rec) }
    }

    // ── Execution ─────────────────────────────────────────────────────────────

    fun onRequestExecute(feature: BypassFeature) {
        val device    = _state.value.device ?: fallbackDevice(feature)
        val sessionId = UUID.randomUUID().toString()
        val plan      = UnifiedBypassRegistry.buildPlan(feature, device, sessionId)

        if (feature.dataLoss || feature.riskLevel >= RiskLevel.HIGH) {
            _state.update { it.copy(activePlan = plan, showPlanDialog = true) }
        } else {
            _state.update { it.copy(activePlan = plan) }
            startExecution(feature, device, sessionId)
        }
    }

    fun onConfirmPlan() {
        val plan = _state.value.activePlan ?: return
        _state.update { it.copy(showPlanDialog = false) }
        startExecution(plan.feature, plan.device, plan.sessionId)
    }

    fun onDismissPlan() {
        _state.update { it.copy(showPlanDialog = false, activePlan = null) }
    }

    private fun startExecution(feature: BypassFeature, device: DeviceState, sessionId: String) {
        if (_state.value.isExecuting) return
        Timber.d("[BYPASS_VM] execute feature=${feature.id} sessionId=$sessionId")

        _state.update { it.copy(
            activeFeatureId = feature.id, isExecuting = true,
            activeEvents = emptyList(), latestEvent = null,
            errorMessage = null, successMessage = null,
        )}

        executeJob = viewModelScope.launch {
            BypassOperationEngine.execute(feature, device, sessionId).collect { event ->
                _state.update { it.copy(latestEvent = event, activeEvents = it.activeEvents + event) }
                when (event) {
                    is BypassEvent.Completed ->
                        _state.update { it.copy(isExecuting = false, successMessage = buildSuccess(event, feature)) }
                    is BypassEvent.Failed ->
                        _state.update { it.copy(isExecuting = false, errorMessage = "[${event.layer}] ${event.reason}") }
                    else -> Unit
                }
            }
        }
    }

    fun cancelExecution() {
        executeJob?.cancel(); executeJob = null
        if (_state.value.isExecuting) _state.update { it.copy(isExecuting = false) }
    }

    // ── UI ────────────────────────────────────────────────────────────────────

    fun onShowDetail(id: String?)  { _state.update { it.copy(detailFeatureId = id) } }
    fun onDismissDetail()          { _state.update { it.copy(detailFeatureId = null) } }
    fun onClearError()             { _state.update { it.copy(errorMessage = null) } }
    fun onClearSuccess()           { _state.update { it.copy(successMessage = null) } }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun applyFilters(features: List<BypassFeature>, f: BypassFilters): List<BypassFeature> {
        var list = features
        f.category?.let    { cat -> list = list.filter { it.category == cat } }
        f.source?.let      { src -> list = list.filter { it.source == src } }
        if (f.freeOnly)       list = list.filter { it.isFree }
        if (f.signalOnly)     list = list.filter { it.signalAfter }
        if (f.untethered)     list = list.filter { it.untethered }
        if (f.noDataLoss)     list = list.filter { !it.dataLoss }
        if (f.noJailbreak)    list = list.filter { !it.requiresJailbreak }
        if (f.offlineOnly)    list = list.filter { !it.requiresInternet }
        if (f.brandFilter.length >= 2) {
            val b = f.brandFilter.lowercase()
            list = list.filter { feat ->
                feat.supportedBrands.isEmpty() ||
                feat.supportedBrands.any { it.lowercase().contains(b) } ||
                feat.tags.any { it.lowercase().contains(b) }
            }
        }
        if (f.searchQuery.length >= 2) {
            val q = f.searchQuery.lowercase()
            list = list.filter { feat ->
                q in feat.displayName.lowercase() ||
                q in feat.description.lowercase() ||
                feat.tags.any { q in it } ||
                feat.supportedBrands.any { q in it.lowercase() } ||
                feat.supportedChipsets.any { q in it.lowercase() }
            }
        }
        return list.sortedWith(compareBy({ it.category.ordinal }, { it.costCredits }))
    }

    private fun fallbackDevice(feature: BypassFeature): DeviceState = DeviceState(
        sessionId    = UUID.randomUUID().toString(),
        ecid         = null, imei = null, serial = null,
        chipName     = feature.chipRange.displayName,
        chipRange    = feature.chipRange,
        iosVersion   = "0",
        buildNumber  = null,
        isJailbroken = false,
        fmiEnabled   = false,
        imeiPresent  = false,
        imeiValid    = false,
        isCdmaMeid   = false,
        activated    = false,
        mdmEnrolled  = false,
        dfuMode      = false,
        adbAvailable = feature.connectionMode == "ADB",
        edlAvailable = feature.connectionMode == "EDL",
        metaAvailable= feature.connectionMode == "META",
    )

    private fun buildSuccess(event: BypassEvent.Completed, feature: BypassFeature): String =
        buildString {
            append("✅ ${feature.displayName} complete. ")
            if (event.signalEnabled) append("📶 Signal active. ")
            if (event.iServices)     append("💬 iMessage+FaceTime active. ")
            if (event.untethered)    append("🔄 Persists after reboot.")
            else                     append("⚠ Re-run after power cycle.")
        }

    override fun onCleared() { super.onCleared(); executeJob?.cancel() }
}
