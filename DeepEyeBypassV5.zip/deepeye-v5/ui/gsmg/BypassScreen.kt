package com.deepeye.otg.ui.gsmg

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.deepeye.otg.data.gsmg.BypassEvent
import com.deepeye.otg.data.gsmg.BypassFeature
import com.deepeye.otg.data.gsmg.BypassMechanism
import com.deepeye.otg.data.gsmg.ChipRange
import com.deepeye.otg.data.gsmg.DeviceState
import com.deepeye.otg.data.gsmg.ExecutionPlan
import com.deepeye.otg.data.gsmg.FeatureCategory
import com.deepeye.otg.data.gsmg.FeatureSource
import com.deepeye.otg.data.gsmg.RiskLevel
import com.deepeye.otg.data.gsmg.UnifiedBypassRegistry

// =============================================================================
// BypassScreen.kt v4.0
// iOS + Android + Modem/Router — 7 tools — 64 features
// =============================================================================

// ── Palette ───────────────────────────────────────────────────────────────────

private val cBg      = Color(0xFF050505)
private val cSurface = Color(0xFF0E0E0E)
private val cCard    = Color(0xFF141414)
private val cBorder  = Color(0xFF252525)
private val cAccent  = Color(0xFF2196F3)
private val cGreen   = Color(0xFF00E676)
private val cOrange  = Color(0xFFFF9800)
private val cRed     = Color(0xFFFF1744)
private val cPurple  = Color(0xFFCE93D8)
private val cCyan    = Color(0xFF00BCD4)
private val cText    = Color(0xFFEEEEEE)
private val cText2   = Color(0xFFAAAAAA)
private val cSub     = Color(0xFF666666)

private fun sourceColor(s: FeatureSource): Color = when (s) {
    FeatureSource.GSMG_IREMOVAL -> Color(0xFF9C27B0)
    FeatureSource.F3ARRAIN      -> Color(0xFF00BCD4)
    FeatureSource.DC_UNLOCKER   -> Color(0xFFFF5722)
    FeatureSource.CHIMERA       -> Color(0xFF2196F3)
    FeatureSource.HYDRA         -> Color(0xFF4CAF50)
    FeatureSource.MIRACLE       -> Color(0xFFFFB300)
    FeatureSource.UNLOCKTOOL    -> Color(0xFF00E5FF)
    FeatureSource.REIBOOT       -> Color(0xFFFF6090)
    FeatureSource.MULTI_TOOL    -> Color(0xFFE040FB)
}

private fun riskColor(r: RiskLevel): Color = when (r) {
    RiskLevel.LOW     -> cGreen
    RiskLevel.MEDIUM  -> cOrange
    RiskLevel.HIGH    -> cRed
    RiskLevel.EXTREME -> Color(0xFFF44336)
}

private fun catColor(c: FeatureCategory): Color = when (c) {
    FeatureCategory.ICLOUD_BYPASS     -> cAccent
    FeatureCategory.PASSCODE          -> cOrange
    FeatureCategory.DEVICE_MANAGEMENT -> cCyan
    FeatureCategory.FIRMWARE          -> Color(0xFFE040FB)
    FeatureCategory.CARRIER           -> cGreen
    FeatureCategory.MDM               -> Color(0xFFFF7043)
    FeatureCategory.SERVICES          -> Color(0xFF26C6DA)
    FeatureCategory.DEVICE_INFO       -> cSub
    FeatureCategory.EXPLOIT_ENGINE    -> cRed
    FeatureCategory.FRP_BYPASS        -> Color(0xFFFF6D00)
    FeatureCategory.IMEI_REPAIR       -> Color(0xFF64FFDA)
    FeatureCategory.NETWORK_UNLOCK    -> cGreen
    FeatureCategory.FIRMWARE_FLASH    -> Color(0xFFE040FB)
    FeatureCategory.BOOTLOADER        -> Color(0xFFFFD740)
    FeatureCategory.ACCOUNT_REMOVE    -> Color(0xFFFF4081)
    FeatureCategory.SCREEN_UNLOCK     -> cOrange
    FeatureCategory.HARDWARE_INFO     -> cSub
    FeatureCategory.EFS_NV            -> Color(0xFF69F0AE)
    FeatureCategory.MODEM_ROUTER      -> Color(0xFF40C4FF)
    FeatureCategory.SAMSUNG_SPECIAL   -> Color(0xFF1565C0)
    FeatureCategory.HUAWEI_SPECIAL    -> Color(0xFFD32F2F)
    FeatureCategory.TRANSSION_SPECIAL -> Color(0xFF2E7D32)
    FeatureCategory.ANDROID_MISC      -> Color(0xFF8BC34A)
}

private fun platformLabel(p: DevicePlatform): String = when (p) {
    DevicePlatform.IOS          -> "🍎 iOS"
    DevicePlatform.ANDROID      -> "🤖 Android"
    DevicePlatform.MODEM_ROUTER -> "📡 Modem"
    DevicePlatform.UNKNOWN      -> "🔍 All"
}

private fun connectionBadgeColor(mode: String): Color = when (mode) {
    "DFU"  -> Color(0xFF00BCD4)
    "ADB"  -> Color(0xFF4CAF50)
    "EDL"  -> Color(0xFFFF5722)
    "BROM" -> Color(0xFFFF9800)
    "META" -> Color(0xFF9C27B0)
    "DIAG" -> Color(0xFF2196F3)
    "ODIN" -> Color(0xFF1565C0)
    else   -> cSub
}

// ── Root screen ───────────────────────────────────────────────────────────────

@Composable
fun BypassScreen(viewModel: BypassViewModel = hiltViewModel()) {
    val st by viewModel.state.collectAsState()

    Box(modifier = Modifier.fillMaxSize().background(cBg)) {
        Column(modifier = Modifier.fillMaxSize()) {

            // Header
            ScreenHeader(st)

            // Platform tabs — iOS / Android / Modem / All
            PlatformTabs(
                selected = st.selectedPlatform,
                onSelect = { viewModel.onSelectPlatform(it) },
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Device banner
            st.device?.let { DeviceBanner(it) }

            // Recommendation
            st.recommendation?.best?.let { best ->
                RecommendedCard(
                    feature   = best,
                    reasoning = st.recommendation!!.reasoning,
                    wantSig   = st.wantSignal,
                    wantFree  = st.wantFree,
                    wantUntet = st.wantUntethered,
                    onExecute = { viewModel.onRequestExecute(best) },
                    onDetails = { viewModel.onShowDetail(best.id) },
                    onRefine  = { s, f, u -> viewModel.onRefineRecommendation(s, f, u) },
                )
            }

            // Search + filters
            SearchFilters(st, viewModel)

            // Category tabs
            CategoryTabs(selected = st.filters.category, onSelect = { viewModel.onCategoryFilter(it) })

            // Source filter row
            SourceFilterRow(selected = st.filters.source, onSelect = { viewModel.onSourceFilter(it) })

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text     = "${st.displayedFeatures.size} / ${st.totalAvailable} features",
                color    = cSub, fontSize = 10.sp,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            Spacer(modifier = Modifier.height(3.dp))

            LazyColumn(
                contentPadding      = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp),
                modifier            = Modifier.weight(1f),
            ) {
                items(st.displayedFeatures, key = { it.id }) { feature ->
                    FeatureCard(
                        feature   = feature,
                        isActive  = st.activeFeatureId == feature.id,
                        onExecute = { viewModel.onRequestExecute(feature) },
                        onDetails = { viewModel.onShowDetail(feature.id) },
                    )
                }
                item { Spacer(modifier = Modifier.height(100.dp)) }
            }
        }

        // Execution overlay
        AnimatedVisibility(
            visible  = st.isExecuting,
            enter    = slideInVertically(tween(300)) { it } + fadeIn(),
            exit     = slideOutVertically(tween(300)) { it } + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter),
        ) {
            ExecutionOverlay(
                event     = st.latestEvent,
                featureId = st.activeFeatureId ?: "",
                onCancel  = { viewModel.cancelExecution() },
            )
        }

        // Plan dialog
        if (st.showPlanDialog) {
            st.activePlan?.let { plan ->
                PlanDialog(
                    plan      = plan,
                    onConfirm = { viewModel.onConfirmPlan() },
                    onDismiss = { viewModel.onDismissPlan() },
                )
            }
        }

        // Error
        st.errorMessage?.let { msg ->
            Snackbar(
                modifier       = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                action         = { TextButton(onClick = { viewModel.onClearError() }) { Text("DISMISS", color = cRed, fontSize = 11.sp) } },
                containerColor = cSurface, contentColor = cText,
            ) { Text(msg, fontSize = 11.sp) }
        }

        // Success
        st.successMessage?.let { msg ->
            Snackbar(
                modifier       = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                action         = { TextButton(onClick = { viewModel.onClearSuccess() }) { Text("OK", color = cGreen, fontSize = 11.sp) } },
                containerColor = cSurface, contentColor = cGreen,
            ) { Text(msg, fontSize = 11.sp) }
        }
    }
}

// ── Screen Header ─────────────────────────────────────────────────────────────

@Composable
private fun ScreenHeader(st: BypassUiState) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text("DEEPEYE BYPASS", color = cText, fontSize = 17.sp,
                    fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("GSMG · iRemoval · F3arRa1n · DC-Unlocker · Chimera · Hydra · Miracle · UnlockTool · ReiBoot",
                    color = cSub, fontSize = 9.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${st.totalAvailable}", color = cAccent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("features", color = cSub, fontSize = 10.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Tool pills
        LazyRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            items(st.sourceBreakdown.entries.filter { it.value > 0 }.toList()) { (src, count) ->
                ToolPill(src = src, count = count)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            MiniChip("${st.freeCount} FREE",            cGreen)
            MiniChip("${st.signalCount} 📶 Signal",     cAccent)
            MiniChip("${UnifiedBypassRegistry.untetheredCount} Untethered", cPurple)
        }
    }
}

// ── Platform Tabs ────────────────────────────────────────────────────────────

@Composable
private fun PlatformTabs(selected: DevicePlatform, onSelect: (DevicePlatform) -> Unit) {
    Row(
        modifier              = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        DevicePlatform.entries.forEach { p ->
            val isSel  = selected == p
            val color  = if (isSel) cAccent else cSub
            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(if (isSel) cAccent.copy(0.15f) else Color.Transparent, RoundedCornerShape(8.dp))
                    .border(1.dp, if (isSel) cAccent else cBorder, RoundedCornerShape(8.dp))
                    .clickable { onSelect(p) }
                    .padding(vertical = 6.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(platformLabel(p), color = color, fontSize = 11.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
    Spacer(modifier = Modifier.height(6.dp))
}

// ── Device Banner ────────────────────────────────────────────────────────────

@Composable
private fun DeviceBanner(device: DeviceState) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        colors   = CardDefaults.cardColors(containerColor = cCard),
        border   = BorderStroke(1.dp, cAccent.copy(alpha = 0.3f)),
        shape    = RoundedCornerShape(8.dp),
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text       = device.androidBrand ?: device.chipName,
                    color      = cAccent, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                )
                Text(
                    text     = buildString {
                        append(device.chipName)
                        device.androidModel?.let { append(" · $it") }
                        if (device.iosVersion != "0") append(" · iOS ${device.iosVersion}")
                        append(" · ${device.chipRange.displayName}")
                    },
                    color = cText2, fontSize = 10.sp,
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                if (device.canUseSignal)  Text("📶 IMEI Valid",  color = cGreen,  fontSize = 10.sp)
                if (device.fmiEnabled)    Text("🔒 FMI ON",      color = cOrange, fontSize = 10.sp)
                if (device.dfuMode)       Text("⚡ DFU",          color = cCyan,   fontSize = 10.sp)
                if (device.adbAvailable)  Text("🟢 ADB",          color = cGreen,  fontSize = 10.sp)
                if (device.edlAvailable)  Text("🔴 EDL",          color = cRed,    fontSize = 10.sp)
            }
        }
    }
}

// ── Recommended Card ─────────────────────────────────────────────────────────

@Composable
private fun RecommendedCard(
    feature:   BypassFeature,
    reasoning: String,
    wantSig:   Boolean,
    wantFree:  Boolean,
    wantUntet: Boolean,
    onExecute: () -> Unit,
    onDetails: () -> Unit,
    onRefine:  (Boolean, Boolean, Boolean) -> Unit,
) {
    var sig   by remember { mutableStateOf(wantSig) }
    var free  by remember { mutableStateOf(wantFree) }
    var untet by remember { mutableStateOf(wantUntet) }

    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        colors   = CardDefaults.cardColors(containerColor = cCard),
        border   = BorderStroke(1.dp, cAccent.copy(0.5f)),
        shape    = RoundedCornerShape(10.dp),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("✨ RECOMMENDED", color = cAccent, fontSize = 9.sp,
                    letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f))
                ToolBadge(feature.source)
                Spacer(modifier = Modifier.width(5.dp))
                RiskBadge(feature.riskLevel)
                Spacer(modifier = Modifier.width(5.dp))
                ConnBadge(feature.connectionMode)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(feature.displayName, color = cText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(feature.description, color = cText2, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(6.dp))
            CapBadgeRow(feature)
            Spacer(modifier = Modifier.height(4.dp))
            Text(reasoning, color = cSub, fontSize = 10.sp)
            Spacer(modifier = Modifier.height(10.dp))
            // Refine
            Text("REFINE:", color = cSub, fontSize = 9.sp, letterSpacing = 1.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ToggleChip("📶 Signal",  sig)  { sig = !sig;  onRefine(sig, free, untet) }
                ToggleChip("FREE",       free) { free = !free; onRefine(sig, free, untet) }
                ToggleChip("Untethered", untet){ untet = !untet; onRefine(sig, free, untet) }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onDetails, modifier = Modifier.weight(1f)) {
                    Text("DETAILS", color = cText2, fontSize = 11.sp)
                }
                Button(
                    onClick  = onExecute, modifier = Modifier.weight(2f),
                    colors   = ButtonDefaults.buttonColors(containerColor = cAccent),
                    shape    = RoundedCornerShape(8.dp),
                ) {
                    Text(if (feature.isFree) "EXECUTE FREE →" else "EXECUTE ${feature.costCredits}¢ →",
                        fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}

// ── Search + Filters ─────────────────────────────────────────────────────────

@Composable
private fun SearchFilters(st: BypassUiState, vm: BypassViewModel) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value         = st.filters.searchQuery,
                onValueChange = { vm.onSearch(it) },
                placeholder   = { Text("Search features, brands, chipsets...", color = cSub, fontSize = 11.sp) },
                modifier      = Modifier.weight(1f).height(48.dp),
                colors        = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = cAccent, unfocusedBorderColor = cBorder,
                    focusedTextColor = cText, unfocusedTextColor = cText, cursorColor = cAccent,
                ),
                singleLine    = true,
                textStyle     = LocalTextStyle.current.copy(fontSize = 12.sp),
            )
            if (st.selectedPlatform == DevicePlatform.ANDROID ||
                st.selectedPlatform == DevicePlatform.MODEM_ROUTER) {
                OutlinedTextField(
                    value         = st.filters.brandFilter,
                    onValueChange = { vm.onBrandFilter(it) },
                    placeholder   = { Text("Brand…", color = cSub, fontSize = 11.sp) },
                    modifier      = Modifier.width(90.dp).height(48.dp),
                    colors        = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = cOrange, unfocusedBorderColor = cBorder,
                        focusedTextColor = cText, unfocusedTextColor = cText, cursorColor = cOrange,
                    ),
                    singleLine    = true,
                    textStyle     = LocalTextStyle.current.copy(fontSize = 12.sp),
                )
            }
        }
        Spacer(modifier = Modifier.height(7.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            item { ToggleChip("FREE",         st.filters.freeOnly)    { vm.onToggleFreeOnly() } }
            item { ToggleChip("📶 Signal",    st.filters.signalOnly)  { vm.onToggleSignalOnly() } }
            item { ToggleChip("Untethered",   st.filters.untethered)  { vm.onToggleUntethered() } }
            item { ToggleChip("No Data Loss", st.filters.noDataLoss)  { vm.onToggleNoDataLoss() } }
            item { ToggleChip("No Jailbreak", st.filters.noJailbreak) { vm.onToggleNoJailbreak() } }
            item { ToggleChip("Offline Only", st.filters.offlineOnly) { vm.onToggleOfflineOnly() } }
        }
    }
}

// ── Category tabs ─────────────────────────────────────────────────────────────

@Composable
private fun CategoryTabs(selected: FeatureCategory?, onSelect: (FeatureCategory?) -> Unit) {
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        item { CatTab("ALL", selected == null, cAccent) { onSelect(null) } }
        items(FeatureCategory.entries) { cat ->
            CatTab("${cat.icon} ${cat.displayName}", selected == cat, catColor(cat)) { onSelect(cat) }
        }
    }
    Spacer(modifier = Modifier.height(5.dp))
}

@Composable
private fun CatTab(label: String, isSel: Boolean, color: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(if (isSel) color.copy(0.15f) else Color.Transparent, RoundedCornerShape(8.dp))
            .border(1.dp, if (isSel) color else cBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 5.dp),
    ) { Text(label, color = if (isSel) color else cSub, fontSize = 11.sp) }
}

// ── Source filter row ────────────────────────────────────────────────────────

@Composable
private fun SourceFilterRow(selected: FeatureSource?, onSelect: (FeatureSource?) -> Unit) {
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        item {
            val isSel = selected == null
            Box(
                modifier = Modifier
                    .background(if (isSel) cAccent.copy(0.15f) else Color.Transparent, RoundedCornerShape(8.dp))
                    .border(1.dp, if (isSel) cAccent else cBorder, RoundedCornerShape(8.dp))
                    .clickable { onSelect(null) }
                    .padding(horizontal = 10.dp, vertical = 4.dp),
            ) { Text("All Tools", color = if (isSel) cAccent else cSub, fontSize = 10.sp) }
        }
        items(FeatureSource.entries) { src ->
            val c     = sourceColor(src)
            val isSel = selected == src
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .background(if (isSel) c.copy(0.15f) else Color.Transparent, RoundedCornerShape(8.dp))
                    .border(1.dp, if (isSel) c else cBorder, RoundedCornerShape(8.dp))
                    .clickable { onSelect(src) }
                    .padding(horizontal = 8.dp, vertical = 4.dp),
            ) {
                Box(modifier = Modifier.size(6.dp).background(c, RoundedCornerShape(3.dp)))
                Spacer(modifier = Modifier.width(4.dp))
                Text(src.displayName, color = if (isSel) c else cSub, fontSize = 10.sp)
            }
        }
    }
    Spacer(modifier = Modifier.height(5.dp))
}

// ── Feature Card ─────────────────────────────────────────────────────────────

@Composable
private fun FeatureCard(
    feature:   BypassFeature,
    isActive:  Boolean,
    onExecute: () -> Unit,
    onDetails: () -> Unit,
) {
    val srcColor = sourceColor(feature.source)

    Card(
        modifier = Modifier.fillMaxWidth().border(1.dp, if (isActive) cGreen else cBorder, RoundedCornerShape(8.dp)),
        colors   = CardDefaults.cardColors(containerColor = cCard),
        shape    = RoundedCornerShape(8.dp),
    ) {
        Row(modifier = Modifier.height(IntrinsicSize.Min)) {
            // Source sidebar
            Box(modifier = Modifier.width(3.dp).fillMaxHeight().background(srcColor))

            Column(modifier = Modifier.weight(1f).padding(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = feature.displayName, color = cText,
                        fontSize = 12.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier.weight(1f),
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    if (feature.isFree) FreeTag()
                    else Text("${feature.costCredits}¢", color = cOrange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Text(feature.description, color = cText2, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)

                // Brands if present
                if (feature.supportedBrands.isNotEmpty()) {
                    Text(
                        text     = feature.supportedBrands.take(4).joinToString(" · "),
                        color    = cSub, fontSize = 9.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }

                Spacer(modifier = Modifier.height(5.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    ConnBadge(feature.connectionMode)
                    ChipBadge(feature.chipRange)
                    if (feature.signalAfter)    IconDot("📶", cGreen)
                    if (feature.untethered)     IconDot("🔄", cPurple)
                    if (feature.iServicesAfter) IconDot("💬", cCyan)
                    if (feature.dataLoss)       IconDot("⚠", cRed)
                    Spacer(modifier = Modifier.weight(1f))
                    Text("${feature.estimatedMinutes.first}–${feature.estimatedMinutes.last}m", color = cSub, fontSize = 9.sp)
                }
            }

            Column(
                modifier              = Modifier.padding(end = 8.dp),
                horizontalAlignment   = Alignment.CenterHorizontally,
                verticalArrangement   = Arrangement.Center,
            ) {
                TextButton(onClick = onDetails, contentPadding = PaddingValues(4.dp)) {
                    Text("ℹ", color = cSub, fontSize = 14.sp)
                }
                TextButton(onClick = onExecute, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)) {
                    Text("RUN →", color = cAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ── Execution Overlay ────────────────────────────────────────────────────────

@Composable
private fun ExecutionOverlay(event: BypassEvent?, featureId: String, onCancel: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(12.dp),
        colors   = CardDefaults.cardColors(containerColor = cSurface),
        border   = BorderStroke(1.dp, cGreen.copy(0.4f)),
        shape    = RoundedCornerShape(10.dp),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("⚡ EXECUTING", color = cGreen, fontSize = 10.sp,
                    letterSpacing = 1.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = onCancel, contentPadding = PaddingValues(4.dp)) {
                    Text("CANCEL", color = cRed, fontSize = 10.sp)
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            when (val ev = event) {
                is BypassEvent.StepBegin -> {
                    Text("Step ${ev.step.stepNum}: ${ev.step.title}", color = cText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Text(ev.step.instruction, color = cText2, fontSize = 11.sp)
                }
                is BypassEvent.NeedUserAction -> {
                    Text("👆 USER ACTION REQUIRED", color = cOrange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(ev.instruction, color = cText, fontSize = 12.sp)
                }
                is BypassEvent.ProgressUpdate -> {
                    Text(ev.currentPhase, color = cText2, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(5.dp))
                    LinearProgressIndicator(
                        progress      = { ev.pct / 100f },
                        modifier      = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color         = cAccent, trackColor = cBorder,
                    )
                    Text("${ev.pct}%", color = cAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.End))
                }
                is BypassEvent.RetryingNow -> {
                    Text("🔄 Retrying ${ev.attempt}/${ev.maxAttempts} — ${ev.backoffMs}ms", color = cOrange, fontSize = 11.sp)
                }
                is BypassEvent.Completed -> {
                    Text("✅ COMPLETED", color = cGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (ev.signalEnabled) MiniChip("📶 Signal", cGreen)
                        if (ev.iServices)     MiniChip("💬 iServices", cCyan)
                        if (ev.untethered)    MiniChip("🔄 Untethered", cPurple)
                    }
                }
                else -> LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)), color = cAccent, trackColor = cBorder)
            }
        }
    }
}

// ── Plan Dialog ───────────────────────────────────────────────────────────────

@Composable
private fun PlanDialog(plan: ExecutionPlan, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor   = cSurface,
        shape            = RoundedCornerShape(12.dp),
        title = {
            Text(if (plan.feature.dataLoss) "⚠ DATA LOSS WARNING" else "Confirm Operation",
                color = if (plan.feature.dataLoss) cRed else cText, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(plan.feature.displayName, color = cText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Text(plan.feature.description, color = cText2, fontSize = 11.sp)

                if (plan.feature.supportedBrands.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Brands: ${plan.feature.supportedBrands.joinToString(", ")}", color = cSub, fontSize = 10.sp)
                }

                if (plan.warnings.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    plan.warnings.forEach { Text("• $it", color = cOrange, fontSize = 11.sp) }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text("Prerequisites:", color = cSub, fontSize = 10.sp)
                plan.prerequisites.forEach { p ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (p.met) "✅" else "❌", fontSize = 12.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(p.name, color = if (p.met) cGreen else cRed, fontSize = 11.sp)
                    }
                    if (!p.met) Text("   → ${p.fixHint}", color = cText2, fontSize = 10.sp)
                }

                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${plan.feature.executionSteps.size} steps", color = cText2, fontSize = 11.sp)
                    Text("·", color = cSub, fontSize = 11.sp)
                    Text("${plan.feature.estimatedMinutes.first}–${plan.feature.estimatedMinutes.last} min", color = cText2, fontSize = 11.sp)
                    Text("·", color = cSub, fontSize = 11.sp)
                    Text(plan.feature.connectionMode, color = connectionBadgeColor(plan.feature.connectionMode), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            Button(
                onClick  = onConfirm,
                enabled  = plan.canExecute,
                colors   = ButtonDefaults.buttonColors(containerColor = if (plan.feature.dataLoss) cRed else cAccent, disabledContainerColor = cBorder),
                shape    = RoundedCornerShape(8.dp),
            ) { Text("CONFIRM & EXECUTE", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("CANCEL", color = cText2, fontSize = 12.sp) } },
    )
}

// ── Reusable composables ──────────────────────────────────────────────────────

@Composable
private fun CapBadgeRow(feature: BypassFeature) {
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
        ConnBadge(feature.connectionMode)
        ChipBadge(feature.chipRange)
        if (feature.signalAfter)    Tag("📶 Signal",    cGreen)
        if (feature.untethered)     Tag("🔄 Untethered", cPurple)
        if (feature.iServicesAfter) Tag("💬 iServices",  cCyan)
        if (feature.dataLoss)       Tag("⚠ Data Loss",  cRed)
    }
}

@Composable
private fun ConnBadge(mode: String) {
    Tag(mode, connectionBadgeColor(mode))
}

@Composable
private fun ChipBadge(chip: ChipRange) {
    Tag(chip.displayName, cSub)
}

@Composable
private fun Tag(text: String, color: Color) {
    Text(text, color = color, fontSize = 9.sp,
        modifier = Modifier
            .background(color.copy(alpha = 0.10f), RoundedCornerShape(4.dp))
            .padding(horizontal = 5.dp, vertical = 2.dp))
}

@Composable
private fun IconDot(icon: String, color: Color) {
    Text(icon, fontSize = 11.sp,
        modifier = Modifier.background(color.copy(0.10f), RoundedCornerShape(3.dp)).padding(2.dp))
}

@Composable
private fun FreeTag() {
    Text("FREE", color = cGreen, fontSize = 9.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.background(cGreen.copy(0.12f), RoundedCornerShape(4.dp)).padding(horizontal = 5.dp, vertical = 2.dp))
}

@Composable
private fun ToolBadge(src: FeatureSource) {
    val c = sourceColor(src)
    Text(src.displayName, color = c, fontSize = 9.sp,
        modifier = Modifier.background(c.copy(0.10f), RoundedCornerShape(4.dp)).padding(horizontal = 5.dp, vertical = 2.dp))
}

@Composable
private fun RiskBadge(risk: RiskLevel) {
    val c = riskColor(risk)
    Text(risk.name, color = c, fontSize = 9.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.background(c.copy(0.12f), RoundedCornerShape(4.dp)).padding(horizontal = 5.dp, vertical = 2.dp))
}

@Composable
private fun ToolPill(src: FeatureSource, count: Int) {
    val c = sourceColor(src)
    Row(verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .background(c.copy(0.10f), RoundedCornerShape(12.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)) {
        Box(modifier = Modifier.size(6.dp).background(c, RoundedCornerShape(3.dp)))
        Spacer(modifier = Modifier.width(4.dp))
        Text("${src.displayName} $count", color = c, fontSize = 9.sp)
    }
}

@Composable
private fun MiniChip(label: String, color: Color) {
    Text(label, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.background(color.copy(0.10f), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 3.dp))
}

@Composable
private fun ToggleChip(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(if (active) cAccent.copy(0.15f) else Color.Transparent, RoundedCornerShape(8.dp))
            .border(1.dp, if (active) cAccent else cBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 5.dp),
    ) { Text(label, color = if (active) cAccent else cSub, fontSize = 11.sp) }
}
