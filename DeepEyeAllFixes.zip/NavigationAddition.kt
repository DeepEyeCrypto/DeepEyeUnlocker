package com.deepeye.otg.ui.navigation

// Add this to your existing BottomNavItem enum or sealed class:

// EXISTING items (do not change):
//   Dashboard, Terminal, Logs, Security
//
// ADD this new item:

// In your NavItem enum/sealed class:
//   object DeviceSupport : NavItem(
//       route   = "device_support",
//       label   = "Devices",
//       icon    = Icons.Outlined.PhoneAndroid,
//   )

// In your NavHost composable (MainScreen.kt or NavGraph.kt):
//   composable("device_support") {
//       DeviceSupportScreen()
//   }

// In your BottomNavigation composable:
//   NavigationBarItem(
//       selected = currentRoute == "device_support",
//       onClick  = { navController.navigate("device_support") },
//       icon     = { Icon(Icons.Outlined.PhoneAndroid, "Devices") },
//       label    = { Text("Devices") },
//   )

// DeviceSupportScreen import:
// import com.deepeye.otg.ui.device.DeviceSupportScreen
