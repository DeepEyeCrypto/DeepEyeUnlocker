# Legal & Disclaimer

## For Educational Purposes Only

DeepEyeUnlocker is provided for educational and research purposes. It is designed to help technicians repairs devices they own or have explicit permission to service.

## Responsibility

The authors and contributors of DeepEyeUnlocker are **NOT responsible** for:

- Any damage to hardware (bricking).
- Data loss.
- Legal issues arising from the use of this tool.
- Misuse of the software for illegal activities.

## IMEI & Network Locks

In many jurisdictions (including India and the USA), tampering with IMEI numbers or bypasssing network locks without authorization is illegal. DeepEyeUnlocker **does not** provide IMEI repair features in its core open-source version to comply with these regulations.

## License

DeepEyeUnlocker is licensed under the MIT License. You are free to use, modify, and distribute it, provided you include the original copyright notice.
